# TicTacToeVsComputer
Tic Tac Toe project vs computer. Computer doesn't utilize any AI it just makes moves on a rand function.
<h3>http://lewismatos.github.io/TicTacToeVsComputer/</h3>
